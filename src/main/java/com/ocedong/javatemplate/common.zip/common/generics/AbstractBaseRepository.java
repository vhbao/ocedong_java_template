package com.ocedong.javatemplate.common.generics;

import com.ocedong.javatemplate.common.models.AbstractAuditingEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import java.io.Serializable;


public interface AbstractBaseRepository<T extends AbstractAuditingEntity, UUID extends Serializable>
    extends JpaRepository<T, UUID>,QuerydslPredicateExecutor<T> {

}
